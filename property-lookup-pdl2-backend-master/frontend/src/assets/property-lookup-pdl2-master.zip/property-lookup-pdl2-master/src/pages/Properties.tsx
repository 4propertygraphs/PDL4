import { useState, useEffect } from 'react';

import AgencyModal from '../components/modals/AgencyModal';
import PropertyDetailsModal from '../components/modals/PropertyModal';
import React from 'react';

import apiService from '../services/ApiService';
import Table from '../components/Table';
import SearchBarModal from '../components/SearchBar.tsx';
import { useSearchParams, useLocation } from 'react-router-dom';

function Properties() {
  const [searchParams] = useSearchParams();
  const [selectedLog, setSelectedLog] = useState<string | null>(null);
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const agencyKey = searchParams.get('key'); // Get agency Key from query params
  const location = useLocation();
  const agency = location.state?.agency || null; // Retrieve agency from state

  const [properties, setProperties] = useState<any[]>([]); // Use `any[]` to handle dynamic data
  const [originalProperties, setOriginalProperties] = useState<any[]>([]); // Add state for original properties
  const [searchText, setSearchText] = useState('');
  const [selectedProperty, setSelectedProperty] = useState<any | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedProperties, setSelectedProperties] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(true); // Add loading state




  const columns = [
    { key: 'Address', label: 'Address' },
    { key: 'Type', label: 'Type' },
    { key: 'Price', label: 'Price' },
    { key: 'Agent', label: 'Agent' },

    { key: 'BathRooms', label: 'Bathrooms' },
    { key: "Beds", label: 'Bedrooms' },
  ];
  const [modalStack, setModalStack] = useState<
    { type: 'createOffice' | 'editOffice' | 'createAgent' | 'editAgent' | 'agency' | 'agencyPipelines'; data?: any }[]
  >([]);


  const closeModal = () => {
    setModalStack((prevStack) => prevStack.slice(0, -1));
  };

  const currentModal = modalStack[modalStack.length - 1];

  const closeLogModal = () => {
    setIsLogModalOpen(false);
    setSelectedLog(null);
  };

  const handleLogDetailsClick = (logId: string) => {
    setSelectedLog(logId);
    setIsLogModalOpen(true);
  };




  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true); // Ensure loading state is set to true before fetching
      try {
        console.log('Fetching properties with agencyKey:', agencyKey); // Debug log
        const [propertiesResponse] = await Promise.all([
          apiService.getProperties(agencyKey || ''),
        ]);
        console.log('Fetched properties:', propertiesResponse.data); // Debug log
        setOriginalProperties(propertiesResponse.data); // Store original properties
        setProperties(propertiesResponse.data); // Initialize displayed properties
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false); // Ensure loading state is set to false after fetching
      }
    };

    fetchData();
  }, [agencyKey]); // Add agencyKey as a dependency

  const handlePropertyClick = (property: any) => {
    setSelectedProperty(property); // Pass the clicked property
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedProperty(null);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedProperties(properties.map(property => property.Id));
    } else {
      setSelectedProperties([]);
    }
  };

  const handleSelectProperty = (Id: number) => {
    setSelectedProperties(prevSelected =>
      prevSelected.includes(Id)
        ? prevSelected.filter(propertyId => propertyId !== Id)
        : [...prevSelected, Id]
    );
  };



  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchText(e.target.value);

  };




  useEffect(() => {
    if (searchText.trim() === '') {
      // Reset properties to original when search text is empty
      setProperties(originalProperties);
    } else {
      // Filter properties based on search text
      setProperties(
        originalProperties.filter((property) =>
          property.Address.toLowerCase().includes(searchText.toLowerCase())
        )
      );
    }
  }, [searchText, originalProperties]);


  const refreshProperties = async () => {
    setIsLoading(true); // Set loading state to true
    try {
      console.log('Refreshing properties with agencyKey:', agencyKey); // Debug log
      const propertiesResponse = await apiService.getProperties(agencyKey || '');
      console.log('Refreshed properties:', propertiesResponse.data); // Debug log

      setOriginalProperties(propertiesResponse.data); // Update original properties
      setProperties(propertiesResponse.data); // Update displayed properties
    } catch (error) {
      console.error('Error refreshing properties:', error);
    } finally {
      setIsLoading(false); // Set loading state to false
    }
  };


  return (
    <>
      {/* Debug log for properties */}


      {/* Search Bar */}
      <SearchBarModal
        searchText={searchText}
        agency={agency} // Pass the agency object
        onSearchChange={handleSearchChange}
        onRefresh={refreshProperties} // Pass refresh function
        title={"Properties of " + agency?.name}
        placeholder="Search properties..."
      />

      <div className="overflow-y-auto max-h-140 shadow-md flex-1 ml-4 mr-4 bg-white dark:bg-gray-900 rounded my-2">
        <Table
          data={properties}
          columns={columns}
          keyField="Id" // Use Id as the unique key
          onRowClick={handlePropertyClick}
          selectedItems={selectedProperties}
          onSelectItem={handleSelectProperty}
          onSelectAll={handleSelectAll}
          isLoading={isLoading} // Pass isLoading to Table
        />
      </div>

      {/* Modals */}


      {currentModal?.type === 'agency' && currentModal.data && (
        <AgencyModal
          show={currentModal?.type === 'agency'}
          agency={currentModal.data}
          onClose={closeModal}

        />
      )}
      {selectedProperty && (
        <PropertyDetailsModal
          show={showModal}
          property={selectedProperty} // Pass the selected property
          onClose={handleCloseModal}
          onLogDetailsClick={handleLogDetailsClick}
          isLogModalOpen={isLogModalOpen}
          selectedLog={selectedLog}
          closeLogModal={closeLogModal}
          apiKey={agency?.myhome_api_key} // Pass the MyHome API key
          acquiantKey={agency?.site_prefix} // Pass the AcquiantCustomer key

        />

      )}


    </>
  );
}

export default Properties;
