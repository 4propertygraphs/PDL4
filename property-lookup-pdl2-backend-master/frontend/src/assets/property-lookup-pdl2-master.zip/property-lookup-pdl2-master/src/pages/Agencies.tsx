import { useState, useEffect } from 'react';
import AgencyModal from '../components/modals/AgencyModal';
import apiService from '../services/ApiService';
import { Agency } from '../interfaces/Models';
import { useNavigate } from 'react-router-dom';
import SearchBarModal from '../components/SearchBar'; // Import SearchBarModal

function Agencies() {
    const [agencies, setAgencies] = useState<Agency[]>([]);
    const [filteredAgencies, setFilteredAgencies] = useState<Agency[]>([]); // Add filtered agencies state
    const [searchText, setSearchText] = useState(''); // Add search text state
    const [isLoading, setIsLoading] = useState(true);
    const [modalStack, setModalStack] = useState<
        { type: 'agency' | 'agencyPipelines'; data?: any }[]
    >([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchAgencies = async () => {
            try {
                const cachedAgencies = localStorage.getItem('agencies');
                if (cachedAgencies) {
                    setAgencies(JSON.parse(cachedAgencies));
                    setFilteredAgencies(JSON.parse(cachedAgencies)); // Initialize filtered agencies
                    setIsLoading(false);
                } else {
                    const agenciesResponse = await apiService.getAgencies();
                    setAgencies(agenciesResponse.data);
                    setFilteredAgencies(agenciesResponse.data); // Initialize filtered agencies
                    localStorage.setItem('agencies', JSON.stringify(agenciesResponse.data));
                }
            } catch (error) {
                console.error('Error fetching agencies:', error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchAgencies();
    }, []);

    useEffect(() => {
        // Filter agencies based on search text
        setFilteredAgencies(
            agencies.filter((agency) =>
                agency.name.toLowerCase().includes(searchText.toLowerCase())
            )
        );
    }, [searchText, agencies]);

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchText(e.target.value); // Update search text
    };

    const refreshAgencies = async () => {
        setIsLoading(true);
        try {
            const agenciesResponse = await apiService.getAgencies();
            setAgencies(agenciesResponse.data);
            localStorage.setItem('agencies', JSON.stringify(agenciesResponse.data));
        } catch (error) {
            console.error('Error refreshing agencies:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const openModal = (type: 'agency' | 'agencyPipelines', data?: any) => {
        setModalStack((prevStack) => [...prevStack, { type, data }]);
    };

    const closeModal = () => {
        setModalStack((prevStack) => prevStack.slice(0, -1));
    };

    const currentModal = modalStack[modalStack.length - 1];

    const handleAgencyClick = (agency: Agency) => {
        navigate(`/properties?key=${encodeURIComponent(agency.key)}`, { state: { agency } }); // Pass agency object in state
    };

    return (
        <div>
            <SearchBarModal
                searchText={searchText}
                onSearchChange={handleSearchChange}
                onRefresh={refreshAgencies} // Pass refresh function
                agency={null}
                title='Agencies'
                placeholder='Search agencies...'
            />



            <div className="overflow-y-auto overflow-x-hidden max-h-140 shadow-md flex-1 ml-4 mr-4 bg-white dark:bg-gray-900 rounded my-2">


                {isLoading ? (
                    <div className="p-4 text-center text-gray-600 dark:text-gray-300">Loading agencies...</div>
                ) : (
                    <div className="p-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {filteredAgencies.map((agency: Agency) => (
                                <div
                                    key={agency.id}
                                    className="bg-white dark:bg-gray-800 shadow-md rounded p-4 cursor-pointer hover:shadow-lg transition-shadow"
                                    onClick={() => handleAgencyClick(agency)}
                                >
                                    <div className="flex justify-between items-center">
                                        <h2 className="text-lg font-medium text-gray-700 dark:text-gray-300">{agency.name}</h2>
                                        <button
                                            className="text-purple-500 cursor-pointer underline"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                openModal('agency', agency);
                                            }}
                                        >
                                            Show
                                        </button>
                                    </div>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{agency.address}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Modals */}
                {currentModal?.type === 'agency' && currentModal.data && (
                    <AgencyModal
                        show={currentModal?.type === 'agency'}
                        agency={currentModal.data}
                        onClose={closeModal}


                    />
                )}

            </div>
        </div>
    );
}

export default Agencies;
