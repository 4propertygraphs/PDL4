import React from 'react';
import { FaSearch, FaSyncAlt } from "react-icons/fa"; // Import refresh icon

interface SearchBarModalProps {
    searchText: string;
    onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onRefresh?: () => void; // Make onRefresh optional
    agency?: any; // Make optional
    title?: string; // Optional title prop
    placeholder?: string; // Optional placeholder prop
}

const SearchBarModal: React.FC<SearchBarModalProps> = ({
    searchText,
    onSearchChange,
    onRefresh,
    placeholder,
    title, // Destructure onRefresh
}) => {
    return (
        <>
            <div className="w-full px-4 py-2">
                <div className="shadow-md w-full bg-white dark:bg-gray-900 dark:text-gray-300 p-4 rounded">
                    <div className="flex justify-between items-center">
                        <h1 className="text-lg font-medium">
                            {title}
                        </h1>
                        {onRefresh && ( // Conditionally render refresh button
                            <button
                                className="p-2 text-black dark:text-gray-300 transition-colors cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 rounded"
                                onClick={onRefresh}
                                title="Refresh Agencies"
                            >
                                <FaSyncAlt className="text-xl" />
                            </button>
                        )}
                    </div>
                </div>
            </div>

            <div className="w-full px-4 py-2">
                <div className="flex items-center relative">
                    <input
                        id="search"
                        type="text"
                        className="shadow-md w-full bg-white dark:bg-gray-900 dark:text-gray-300 p-4 pl-12 rounded focus:outline-none focus:ring-2 focus:ring-purple-400"
                        placeholder={placeholder} // Updated placeholder
                        value={searchText}
                        onChange={onSearchChange}
                    />
                    <span className="absolute left-4 text-gray-500 dark:text-gray-300">
                        <FaSearch />
                    </span>
                </div>
            </div>
        </>
    );
};

export default SearchBarModal;
