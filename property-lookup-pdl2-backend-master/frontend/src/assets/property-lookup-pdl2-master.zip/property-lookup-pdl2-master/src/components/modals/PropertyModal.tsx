import React, { useEffect, useState } from 'react';
import Modal from '../Modal';
import apiService from '../../services/ApiService';

interface PropertyDetailsModalProps {
    show: boolean;
    property: any | null;
    onClose: () => void;
    onLogDetailsClick: (logId: string) => void;
    isLogModalOpen: boolean;
    selectedLog: string | null;
    closeLogModal: () => void;
    apiKey: string | null; // MyHome API key
    acquiantKey: string | null; // AcquiantCustomer key
}

const PropertyDetailsModal: React.FC<PropertyDetailsModalProps> = ({
    show,
    property,
    onClose,
    apiKey,
    acquiantKey,
}) => {
    const [additionalInfo, setAdditionalInfo] = useState<any | null>('Loading...');
    const [acquaintInfo, setAcquaintInfo] = useState<any | null>('Loading...');

    useEffect(() => {
        const fetchData = async () => {
            try {
                if (property?.ListReff) {
                    if (apiKey) {
                        try {
                            const myhome = await apiService.getMyHome(apiKey, property.ListReff);
                            setAdditionalInfo(myhome.data.Property);
                        } catch (error: any) {
                            if (error.response?.data?.message) {
                                setAdditionalInfo({ message: error.response.data.message });
                            } else {
                                setAdditionalInfo({ message: 'Failed to fetch MyHome data.' });
                            }
                        }
                    } else {
                        setAdditionalInfo({ message: 'MyHome API key is missing.' });
                    }

                    if (acquiantKey) {
                        try {
                            const acquaint = await apiService.GetAcquaint(acquiantKey, property.ListReff);
                            setAcquaintInfo(acquaint.data);
                        } catch (error: any) {
                            if (error.response?.data?.error) {
                                setAcquaintInfo({ message: error.response.data.error });
                            } else {
                                setAcquaintInfo({ message: error.response.data.message });
                            }
                        }
                    } else {
                        setAcquaintInfo({ message: 'Acquaint API key is missing.' });
                    }
                }
            } catch (error) {
                console.error('Error fetching property info:', error);
            }
        };

        fetchData();
    }, [property, apiKey, acquiantKey]);

    if (!property) return null;

    const CollapsibleText: React.FC<{ text: string }> = ({ text }) => {
        const [isCollapsed, setIsCollapsed] = useState(true);
        const maxLength = 100;

        if (text.length <= maxLength) return <span className="break-words">{text}</span>;

        return (
            <span className="break-words">
                {isCollapsed ? `${text.slice(0, maxLength)}...` : text}
                <button
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="text-blue-500 ml-2 underline"
                >
                    {isCollapsed ? 'Show more' : 'Show less'}
                </button>
            </span>
        );
    };

    const renderData = (data: any, compareTo?: any) => {

        if (typeof data === 'string') {
            return <CollapsibleText text={data} />;
        } else if (typeof data === 'object' && data !== null) {
            return (
                <table className="w-full text-left text-md dark:text-gray-300">
                    <tbody>
                        {Object.keys(data).map(key => {
                            const value = data[key];
                            const compareValue = compareTo?.[key];

                            const isDifferent =
                                typeof value === 'string' &&
                                typeof compareValue === 'string' &&
                                value.trim() !== compareValue.trim();

                            return (
                                <tr key={key} className="border-b border-gray-200 dark:border-gray-700">
                                    <th className="font-medium px-2 py-1 break-words">{key}</th>
                                    <td
                                        className={`font-normal px-2 py-1 break-words ${isDifferent ? 'text-red-500 font-semibold' : ''
                                            }`}
                                    >
                                        {typeof value === 'object'
                                            ? renderData(value, compareValue)
                                            : value?.toString()}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            );

        } else {
            return <span>{data}</span>;
        }
    };

    const infoSections = [
        { title: 'FindAHome', data: property },
        { title: 'MyHome', data: additionalInfo },
        { title: 'Acquaint', data: acquaintInfo },
    ];

    return (
        <Modal show={show} onClose={onClose} title={property.Address}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {infoSections.map((section, index) => {
                    const compareTo =
                        section.title === 'FindAHome'
                            ? additionalInfo
                            : section.title === 'MyHome'
                                ? property
                                : null;

                    return (
                        <div key={index}>
                            <h3 className="text-lg font-medium mb-2 dark:text-gray-300 bg-white dark:bg-gray-900 z-10 p-2 w-full">
                                {section.title}
                            </h3>
                            <div className="overflow-y-auto max-h-130 border border-gray-200 dark:border-gray-700 rounded p-4">
                                {section.data.message ? (
                                    <p className="dark:text-gray-300">{section.data.message}</p>
                                ) : (
                                    renderData(section.data, compareTo)
                                )}
                                {/* Image logic unchanged */}
                            </div>
                        </div>
                    );
                })}

            </div>
        </Modal>
    );
};

export default PropertyDetailsModal;